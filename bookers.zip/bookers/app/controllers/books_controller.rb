class BooksController < ApplicationController
  def show
  @book = Book.find(params[:id])
  end

  def index
  @books = Book.all
  @book = Book.new   #追記
  end

  def new
  @book = Book.new
  end

  # ---- 下記2行を追加してください ---- #
  def create
  # ---- ここからコードを書きましょう ---- #
  @book = Book.new(book_params)
  if @book.save
      # flashというハッシュに :notice をいうキーで '投稿が完了しました！' という文字列の値を保存
      flash[:notice] = 'successfully＝投稿が完了しました！'
       # ---- show画面に偏移 ---- #
  redirect_to book_path(@book)

  else
      @books = Book.all
      flash[:notice4] = 'error＝投稿に失敗しました！'
  # 投稿一覧画面へ
      render :index

  end
  end

  def edit
  @book = Book.find(params[:id])
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
    flash[:notice2] = 'successfully＝更新・編集が完了しました！'
    # ---- show画面に偏移 ---- #
    redirect_to book_path(@book)

    else
     flash[:notice5] = 'error＝更新・編集に失敗しました！'
      render("edit")
    end
  end

  def destroy
    book = Book.find(params[:id])  # データ（レコード）を1件取得
    book.destroy  # データ（レコード）を削除
    flash[:notice3] = 'successfully＝削除が完了しました！'
    redirect_to index

     # 投稿一覧画面へリダイレクト
  end



# ---- 以下を追加してください ---- #
  private
  def book_params
    params.require(:book).permit(:title, :body)
  end
end